# 
# Ejercicio 13 de Procesos
#

#!/bin/bash

ls -al  > ./stdout

cat stdout
