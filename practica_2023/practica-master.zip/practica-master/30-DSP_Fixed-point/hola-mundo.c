
#include <limits.h>
#include <stdio.h>
#include <stdint.h>

int main(void)
{	
		printf("Hola mundo \n");
		
		printf("%d \n" , INT_MAX);
		printf("%d \n" , INT_MIN);

		return 0;
}
